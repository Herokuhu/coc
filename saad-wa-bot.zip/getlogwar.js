require('dotenv').config();
const fs = require('fs');
const fetch = require('node-fetch');

const API_TOKEN = process.env.COC_API_KEY || '';
const DB_PATH = './db.json';
const LOCK_PATH = './getlogwar.lock';

// ================= UTILITIES ====================
function standardTag(tag) {
  const t = tag ? tag.replace('#', '').toUpperCase().trim() : '';
  return t ? `#${t}` : '';
}

// ============= NORMAL WAR FINALIZER ==============
function finalizeNormalWarLogs(db, warData, clanTag, maxAttacks = 2) {
  if (warData.state !== "warEnded") return;
  const myTagClean = standardTag(clanTag);
  const oppTagClean = standardTag(warData.opponent?.tag);
  const warId = `${myTagClean}_${oppTagClean}_${warData.startTime || warData.preparationStartTime || warData.endTime}`;

  for (const [playerTag, logs] of Object.entries(db.playerWarLogs)) {
    const preserved = logs.filter(
      l => !(l.warId === warId && (l.isCwl === false || typeof l.isCwl === "undefined"))
    );
    const warLogs = logs.filter(
      l => l.warId === warId && (l.isCwl === false || typeof l.isCwl === "undefined")
    );
    const realAttacks = warLogs.filter(
      l => !l.unused && (l.stars > 0 || l.destructionPercentage > 0)
    );
    realAttacks.sort((a, b) => (a.order ?? 9999) - (b.order ?? 9999));
    const kept = realAttacks.slice(0, maxAttacks);
    const finalizedForPlayer = [];

    kept.forEach((attack, idx) => {
      finalizedForPlayer.push({
        ...attack,
        clanTag: myTagClean,
        oppClanTag: oppTagClean,
        warId,
        order: idx + 1,
        isFromLive: false,
        finalized: true,
        isCwl: false,
        warKey: `${warId}_${playerTag}_${idx + 1}`,
      });
    });

    for (let order = kept.length + 1; order <= maxAttacks; order++) {
      finalizedForPlayer.push({
        warId,
        clanTag: myTagClean,
        oppClanTag: oppTagClean,
        myClan: warData.clan?.name || "Unknown",
        oppClan: warData.opponent?.name || "Unknown",
        myName: "Unknown", oppName: "Not used",
        stars: 0, destructionPercentage: 0,
        order, defenderTag: null,
        unused: true, isFromLive: false, finalized: true, isCwl: false,
        time: new Date().toISOString(),
        warKey: `${warId}_${playerTag}_${order}`,
      });
    }

    db.playerWarLogs[playerTag] = [...preserved, ...finalizedForPlayer];
    if (db.playerWarLogs[playerTag].length > 30)
      db.playerWarLogs[playerTag] = db.playerWarLogs[playerTag].slice(-30);
  }
}

// ============== CWL WAR FINALIZER ================
function finalizeCwlWarLogs(db, warData, clanTag, cwlRound) {
  if (warData.state !== "warEnded") return;

  const myTagClean = standardTag(clanTag);
  const oppTagClean = standardTag(warData.opponent?.tag);
  if (myTagClean === oppTagClean) return;

  const warId = `CWL_${myTagClean}_${oppTagClean}_${warData.startTime || warData.preparationStartTime || warData.endTime}_R${cwlRound}`;

  for (const [playerTag, logs] of Object.entries(db.playerWarLogs)) {
    let preserved = logs.filter(l => !(l.warId === warId && l.isCwl === true && l.cwlRound === cwlRound));
    // Find any old log for this war (either isFromLive:true OR isFromLive: false but not finalized yet)
    let candidateLogs = logs.filter(
      l => l.warId === warId && l.isCwl === true && l.cwlRound === cwlRound &&
      (!l.finalized || l.isFromLive)
    );

    const realAttack = candidateLogs.find(
      attack => !attack.unused && (attack.stars > 0 || attack.destructionPercentage > 0)
    );
    const finalizedForPlayer = [];
    if (realAttack) {
      finalizedForPlayer.push({
        ...realAttack,
        clanTag: myTagClean,
        oppClanTag: oppTagClean,
        warId,
        isFromLive: false,
        finalized: true,
        cwlRound,
        isCwl: true,
        order: 1,
        warKey: `${warId}_${playerTag}_1`
      });
    }

    db.playerWarLogs[playerTag] = [...preserved, ...finalizedForPlayer];
    if (db.playerWarLogs[playerTag].length > 30)
      db.playerWarLogs[playerTag] = db.playerWarLogs[playerTag].slice(-30);
  }
}


// ==== FINALIZE ALL ENDED CWL WARS ====
async function finalizeAllEndedCwlWars(db, clanTag) {
  const league = await cocFetch(`/clans/${encodeURIComponent(clanTag)}/currentwar/leaguegroup`);
  const rounds = league.rounds || [];
  for (let i = 0; i < rounds.length; i++) {
    const round = rounds[i];
    if (!Array.isArray(round.warTags)) continue;
    for (const warTag of round.warTags) {
      if (!warTag || warTag === '#0') continue;
      try {
        const war = await cocFetch(`/clanwarleagues/wars/${encodeURIComponent(warTag)}`);
        const myTagClean = standardTag(clanTag);
        const oppTagClean = standardTag(war.opponent?.tag);
        if (war.state === 'warEnded' && myTagClean !== oppTagClean) {
          finalizeCwlWarLogs(db, war, clanTag, i + 1);
        }
      } catch (e) {}
    }
  }
}

// ================= MAIN ==========================
(async () => {
  if (fs.existsSync(LOCK_PATH)) {
    console.log("Another instance is already running. Exiting.");
    process.exit(0);
  }
  fs.writeFileSync(LOCK_PATH, "locked");

  const cleanupLock = () => {
    try { if (fs.existsSync(LOCK_PATH)) fs.unlinkSync(LOCK_PATH); } catch (_) {}
  };
  process.on("exit", cleanupLock);
  process.on("SIGINT", () => { cleanupLock(); process.exit(0); });
  process.on("SIGTERM", () => { cleanupLock(); process.exit(0); });
  process.on("uncaughtException", (err) => {
    console.error("Uncaught Exception:", err);
    cleanupLock();
    process.exit(1);
  });

  try {
    if (!fs.existsSync(DB_PATH)) {
      console.error("❌ db.json not found. Abort.");
      process.exit(1);
    }
    const rawData = await fs.promises.readFile(DB_PATH, "utf8");
    const db = JSON.parse(rawData);

    db.playerWarLogs = db.playerWarLogs || {};
    db.userClans = db.userClans || {};
    const clans = new Set(
      Object.values(db.userClans)
        .map((c) => (typeof c === "string" ? c : c.clanTag))
        .filter(Boolean)
    );

    // Finalize all normal ended wars
    for (const clanTag of clans) {
      try {
        const warData = await cocFetch(`/clans/${encodeURIComponent(clanTag)}/currentwar`);
        const myTagClean = standardTag(clanTag);
        const oppTagClean = standardTag(warData.opponent?.tag);
        if (warData && warData.state === "warEnded" && !warData.isCwl) {
          finalizeNormalWarLogs(db, warData, clanTag, 2);
        }
      } catch (err) {}
    }

    // Finalize ALL ENDED CWL wars (skip dummy/self-opponent)
    for (const clanTag of clans) {
      try {
        await finalizeAllEndedCwlWars(db, clanTag);
      } catch (err) {}
    }

    const tmpFile = DB_PATH + ".tmp";
    await fs.promises.writeFile(tmpFile, JSON.stringify(db, null, 2), "utf-8");
    await fs.promises.rename(tmpFile, DB_PATH);
    console.log("✅ db.json finalized successfully (clean CWL, only real attacks, standardized tags).");
  } catch (err) {
    console.error("❌ Error in getlogwar.js:", err);
  } finally {
    cleanupLock();
  }
})();
