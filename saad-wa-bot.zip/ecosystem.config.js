module.exports = {
  apps: [
    {
      name: "bot",
      script: "./px78.js",
      watch: false
    },
    {
      name: "attendance-updater",
      script: "./at4.js",
      cron_restart: "*/10 * * * *", // har 10 minute chalega
      autorestart: false,
      watch: false
    }
  ]
};
