// ✅ CWL War Finalizer (re-coded, stable version)
require("dotenv").config();
const fs = require("fs");
const fetch = require("node-fetch");

const API_TOKEN = process.env.COC_API_KEY || "";
const DB_PATH = "./db.json";

function standardTag(tag) {
  const t = tag ? tag.replace("#", "").toUpperCase().trim() : "";
  return t ? `#${t}` : "";
}

async function cocFetch(apiPath) {
  const url = `https://api.clashofclans.com/v1${apiPath}`;
  const res = await fetch(url, { headers: { Authorization: `Bearer ${API_TOKEN}` } });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`API ${apiPath} failed: ${res.status} → ${text}`);
  }
  return await res.json();
}

(async () => {
  try {
    // --- DB load ---
    if (!fs.existsSync(DB_PATH)) throw new Error("❌ db.json not found.");
    const rawData = await fs.promises.readFile(DB_PATH, "utf8");
    const db = JSON.parse(rawData);

    db.playerWarLogs = db.playerWarLogs || {};
    db.userClans = db.userClans || {};

    const anyClanTag = Object.values(db.userClans)[0] || Object.keys(db.userClans)[0];
    if (!anyClanTag) throw new Error("❌ No clan found in userClans.");
    console.log("📌 Using clan:", anyClanTag);

    // --- Fetch league group ---
    const league = await cocFetch(`/clans/${encodeURIComponent(anyClanTag)}/currentwar/leaguegroup`);
    if (!league.rounds) throw new Error("❌ No CWL rounds found for this clan.");
    const rounds = league.rounds;

    // Blocking (ignore some clans)
    const SKIP_TAGS = new Set(["#22YR0GGUV", "#PPLPCLL8"]);

    // Collect live wars
    const liveWarIds = new Set();

    for (const round of rounds) {
      for (const warTag of round.warTags || []) {
        if (!warTag || warTag === "#0") continue;
        const war = await cocFetch(`/clanwarleagues/wars/${encodeURIComponent(warTag)}`);
        if (!war.clan || !war.opponent) continue;

        const clanTagUpper = war.clan.tag.toUpperCase();
        const oppTagUpper = war.opponent.tag.toUpperCase();
        if (SKIP_TAGS.has(clanTagUpper) || SKIP_TAGS.has(oppTagUpper)) {
          console.log(`⏩ Skipping blocked clans: ${clanTagUpper} vs ${oppTagUpper}`);
          continue;
        }

        if (war.state === "inWar") {
          const warId = `${standardTag(war.clan.tag)}_${standardTag(war.opponent.tag)}_${war.startTime || war.preparationStartTime}`;
          liveWarIds.add(warId);
          console.log(`⏩ Skipping live war ${warTag}`);
        }
      }
    }

    let totalLogs = 0, totalWars = 0;

    // Process all rounds
    for (let roundIdx = 0; roundIdx < rounds.length; roundIdx++) {
      const round = rounds[roundIdx];
      for (const warTag of round.warTags || []) {
        if (!warTag || warTag === "#0") continue;

        const war = await cocFetch(`/clanwarleagues/wars/${encodeURIComponent(warTag)}`);
        if (!war.clan || !war.opponent) continue;

        const warId = `${standardTag(war.clan.tag)}_${standardTag(war.opponent.tag)}_${war.startTime || war.preparationStartTime}`;
        if (liveWarIds.has(warId)) continue;

        // CWL check: member count
        const memberCount = (war.clan.members?.length || 0) + (war.opponent.members?.length || 0);
        if (![30, 60, 90].includes(memberCount)) {
          console.log(`⏩ Skipping suspicious war (member count ${memberCount}): ${warTag}`);
          continue;
        }

        if (!["preparation", "warEnded"].includes(war.state)) continue;
        totalWars++;

        // Defender map
        const tagToName = {};
        (war.clan.members || []).forEach(m => tagToName[m.tag] = m.name);
        (war.opponent.members || []).forEach(m => tagToName[m.tag] = m.name);

        for (const side of ["clan", "opponent"]) {
          for (const m of war[side].members || []) {
            db.playerWarLogs[m.tag] = db.playerWarLogs[m.tag] || [];

            // remove duplicates from same round/war
            db.playerWarLogs[m.tag] = db.playerWarLogs[m.tag].filter(
              l => l.cwlRound !== roundIdx + 1 || l.warId !== warId
            );

            if (Array.isArray(m.attacks)) {
              m.attacks.forEach((atk, idx) => {
                db.playerWarLogs[m.tag].push({
                  warKey: `${war.clan.tag}_${war.opponent.tag}_${war.startTime}_${m.tag}_${idx+1}`,
                  warId,
                  clanTag: war[side].tag,
                  oppClanTag: war[side === "clan" ? "opponent" : "clan"].tag,
                  myClan: war[side].name,
                  oppClan: war[side === "clan" ? "opponent" : "clan"].name,
                  myName: m.name,
                  oppName: tagToName[atk.defenderTag] || "Unknown",
                  stars: atk.stars,
                  destructionPercentage: atk.destructionPercentage,
                  order: idx + 1,
                  defenderTag: atk.defenderTag,
                  isFromLive: false,
                  unused: false,
                  cwlRound: roundIdx + 1,
                  time: new Date().toISOString(),
                });
                totalLogs++;
              });
            }

            // Limit max logs per player
            const MAX_CWL_LOGS = 50;
            if (db.playerWarLogs[m.tag].length > MAX_CWL_LOGS) {
              db.playerWarLogs[m.tag] = db.playerWarLogs[m.tag].slice(-MAX_CWL_LOGS);
            }
          }
        }
      }
    }

    // Save DB
    await fs.promises.writeFile(DB_PATH, JSON.stringify(db, null, 2), "utf8");
    console.log(`✅ Finalized CWL logs (${totalLogs} logs in ${totalWars} war(s)), skipping live + blocked wars.`);
  } catch (err) {
    console.error("❌ Error:", err.message);
  }
})();