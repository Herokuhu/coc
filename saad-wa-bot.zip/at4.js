// attendance.js
// ------------------------- 🧮 Attendance Logs System (standalone) -------------------------

require("dotenv").config();

// Node 18+ has global fetch. If you’re on older Node, uncomment the next line:
// const fetch = require("node-fetch");

// --- Resolve DB helpers safely (works whether db.js exports loadDB/saveDB or load/write/etc.)
const dbMod = require("./db");
const loadDB =
  dbMod.loadDB || dbMod.load || dbMod.read || dbMod.get ||
  (() => { throw new Error("db.js must export loadDB/load/read/get"); });

const saveDB =
  dbMod.saveDB || dbMod.save || dbMod.write || dbMod.set ||
  (() => { throw new Error("db.js must export saveDB/save/write/set"); });

// ------------------------- Utilities -------------------------
const ATT_SECTION = "attendance";

// Canonicalize tag so read & write use the SAME key
function canonTag(tag) {
  if (!tag) return null;
  let t = String(tag).trim().toUpperCase().replace(/O/g, "0");
  if (!t.startsWith("#")) t = "#" + t;
  return t;
}

// Lightweight retry wrapper for CoC API
async function cocFetch(endpoint, { retries = 2, timeoutMs = 12000 } = {}) {
  const url = `https://api.clashofclans.com/v1${endpoint}`;
  let lastErr;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), timeoutMs);
      const res = await fetch(url, {
        headers: {
          "Authorization": `Bearer ${process.env.COC_API_KEY}`,
          "Accept": "application/json"
        },
        signal: ctrl.signal
      });
      clearTimeout(timer);

      if (!res.ok) {
        // Backoff on transient
        if (res.status >= 500 || res.status === 429) {
          lastErr = new Error(`HTTP ${res.status} on ${endpoint}`);
          await new Promise(r => setTimeout(r, 500 * (attempt + 1)));
          continue;
        }
        // Non-retriable
        const body = await res.text().catch(() => "");
        throw new Error(`HTTP ${res.status} on ${endpoint} :: ${body}`);
      }
      return res.json();
    } catch (e) {
      lastErr = e;
      // retry on abort/network
      if (attempt < retries) {
        await new Promise(r => setTimeout(r, 500 * (attempt + 1)));
        continue;
      }
    }
  }
  throw lastErr || new Error(`Unknown error calling ${endpoint}`);
}

// ------------------------- Attendance core -------------------------
async function collectPresentFromNormal(clanTag) {
  const present = new Set();
  try {
    const liveWar = await cocFetch(`/clans/${encodeURIComponent(clanTag)}/currentwar`);
    if (liveWar?.state === "inWar" && Array.isArray(liveWar?.clan?.members)) {
      for (const m of liveWar.clan.members) {
        if (Array.isArray(m.attacks) && m.attacks.length > 0) present.add(m.tag);
      }
      console.log(`⚔️ Normal inWar: ${present.size} present`);
    }
  } catch (e) {
    console.log(`ℹ️ normal currentwar fetch skipped: ${e.message}`);
  }
  return present;
}

async function collectPresentFromCWL(clanTag) {
  const present = new Set();
  try {
    const league = await cocFetch(`/clans/${encodeURIComponent(clanTag)}/currentwar/leaguegroup`);
    const rounds = Array.isArray(league?.rounds) ? league.rounds : [];
    for (const round of rounds) {
      const tags = Array.isArray(round?.warTags) ? round.warTags : [];
      for (const warTag of tags) {
        if (!warTag || warTag === "#0") continue;
        try {
          const cwlWar = await cocFetch(`/clanwarleagues/wars/${encodeURIComponent(warTag)}`);
          if (cwlWar?.state !== "inWar") continue;

          // pick side
          const isMine = String(cwlWar?.clan?.tag || "").toUpperCase() === clanTag;
          const members = isMine ? (cwlWar?.clan?.members || []) : (cwlWar?.opponent?.members || []);
          for (const m of members) {
            if (Array.isArray(m.attacks) && m.attacks.length > 0) present.add(m.tag);
          }
          console.log(`⚔️ CWL inWar [${warTag}]: ${present.size} cumulative present`);
        } catch (e) {
          console.log(`ℹ️ cwl war fetch failed ${warTag}: ${e.message}`);
        }
      }
    }
  } catch (e) {
    console.log(`ℹ️ leaguegroup fetch skipped: ${e.message}`);
  }
  return present;
}

async function updateAttendanceForClan(rawTag) {
  const tag = canonTag(rawTag);
  if (!tag) return;

  console.log(`\n🔎 Updating attendance for ${tag} ...`);

  // Gather present players from both sources (union)
  const [normalPresent, cwlPresent] = await Promise.all([
    collectPresentFromNormal(tag),
    collectPresentFromCWL(tag),
  ]);

  const presentPlayers = new Set([...normalPresent, ...cwlPresent]);
  // ✅ Only update if at least one player attacked
  if (presentPlayers.size === 0) {
    console.log(`⏸️ No attacks recorded yet for ${tag}, skipping update (avoiding 100% absent).`);
    return;
  }

  // Pull latest members after confirming war running
  const [clanInfo, clanMembers] = await Promise.all([
    cocFetch(`/clans/${encodeURIComponent(tag)}`),
    cocFetch(`/clans/${encodeURIComponent(tag)}/members`),
  ]);

  const items = Array.isArray(clanMembers?.items) ? clanMembers.items : [];
  const currentTags = items.map(m => m.tag);
  const total = items.length;
  const presentCount = items.filter(m => presentPlayers.has(m.tag)).length;
  const absentCount = Math.max(0, total - presentCount);

  // Load -> mutate -> save (to avoid clobbering concurrent writers)
  const DB = await loadDB();

  // Ensure structures & canonical key
  DB.attendanceLogs = DB.attendanceLogs || {};
  DB.attendanceLogs[tag] = DB.attendanceLogs[tag] || {};
  if (!Array.isArray(DB.attendanceLogs[tag].records)) DB.attendanceLogs[tag].records = [];

  const prevMembers = Array.isArray(DB.attendanceLogs[tag]?.lastSnapshot?.lastMembers)
    ? DB.attendanceLogs[tag].lastSnapshot.lastMembers
    : [];

  const joined = currentTags.filter(t => !prevMembers.includes(t));
  const leaved = prevMembers.filter(t => !currentTags.includes(t));

  // prune >30 days
  const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;
  DB.attendanceLogs[tag].records = DB.attendanceLogs[tag].records.filter(r => r?.timestamp >= cutoff);

  const snapshot = {
    timestamp: Date.now(),
    clanName: clanInfo?.name || "Unknown Clan",
    total,
    present: presentCount,
    absent: absentCount,
    percentPresent: total ? ((presentCount / total) * 100).toFixed(1) : "0.0",
    percentAbsent: total ? ((absentCount / total) * 100).toFixed(1) : "0.0",
    joined,
    leaved,
    lastMembers: currentTags,
  };

  DB.attendanceLogs[tag].lastSnapshot = snapshot;
  DB.attendanceLogs[tag].lastUpdated = snapshot.timestamp;
  DB.attendanceLogs[tag].clanName = snapshot.clanName;
  DB.attendanceLogs[tag].total = snapshot.total;
  DB.attendanceLogs[tag].present = snapshot.present;
  DB.attendanceLogs[tag].absent = snapshot.absent;
  DB.attendanceLogs[tag].percentPresent = snapshot.percentPresent;
  DB.attendanceLogs[tag].percentAbsent = snapshot.percentAbsent;
  DB.attendanceLogs[tag].records.push(snapshot);

  await saveDB(ATT_SECTION);
  console.log(`✅ Attendance updated for ${tag}: ${presentCount}/${total}`);
}

// ------------------------- Runner -------------------------
(async () => {
  const DB = await loadDB();

  // Collect unique, canonical clan tags from userClans
  const rawList = Object.values(DB.userClans || {})
    .map(c => (typeof c === "string" ? c : c?.clanTag))
    .filter(Boolean);

  const tags = [...new Set(rawList.map(canonTag))];
  if (tags.length === 0) {
    console.log("ℹ️ No clans configured in DB.userClans");
    process.exit(0);
  }

  for (const t of tags) {
    try {
      await updateAttendanceForClan(t);
    } catch (e) {
      console.error(`❌ Update failed for ${t}:`, e.message);
    }
  }

  console.log("🏁 Attendance update finished.");
  process.exit(0);
})();
