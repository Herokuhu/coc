// db.js
// ------------------------- 📂 Simple JSON DB Helper -------------------------

const fs = require("fs").promises;
const path = require("path");

const DB_PATH = path.join(__dirname, "db.json");

// ✅ Load DB from disk (and cache into global.DB)
async function loadDB() {
  if (global.DB) return global.DB; // reuse if already loaded
  try {
    const raw = await fs.readFile(DB_PATH, "utf8");
    global.DB = JSON.parse(raw);
  } catch (e) {
    if (e.code === "ENOENT") {
      global.DB = {}; // fresh DB if file not found
    } else {
      throw e;
    }
  }
  return global.DB;
}

// ✅ Save DB back to disk
async function saveDB(section = "full") {
  if (!global.DB) global.DB = {};
  try {
    await fs.writeFile(DB_PATH, JSON.stringify(global.DB, null, 2), "utf8");
    console.log(`✅ DB saved successfully [${section}]`);
  } catch (e) {
    console.error(`❌ DB save failed [${section}]:`, e.message);
  }
}

module.exports = { loadDB, saveDB };
